# -*- coding: utf-8 -*-
'''
这个是演示的主程序，通过选择一下两种产生rag的方式，可以决定slic mask之间是否能merge
g=rag.construct_rag(lab,segments_slic,region_fh,slicNum,binNum)
#g=global_rag.construct_rag(img,segments_slic,region_fh,slicNum,binNum)

'''

from __future__ import print_function
from skimage.segmentation import relabel_sequential
import matplotlib.pyplot as plt
import numpy
from skimage import io, color,filter
from skimage.data import lena
from skimage.segmentation import felzenszwalb, slic, quickshift
from skimage.segmentation import mark_boundaries
from skimage.util import img_as_float
import fh
import rag
import global_rag
import PIL.Image
import rag_graph
from datetime import datetime
from break2Build import buildFinalLabel
import pickle
from scipy.ndimage.filters import gaussian_filter
import scipy.io as sio

'''
[::2,::2]表示每隔两个index娶一个sample，就是down-sampling
'''

img = numpy.array(PIL.Image.open("fishMan.jpg"))
print (type(img))
lab = color.rgb2lab(img)
print (type(lab))
print (lab.shape)
#img = img_as_float(lena()[::2, ::2])
n_segments=100

'''
#best
c=10
min_size=100
sigma=0.8
binNum=5
'''
c=10
min_size=100
sigma=0.7
binNum=5
plt.figure()
segments_slic = slic(img, n_segments, compactness=10, sigma=1,enforce_connectivity=True)
slicNum=len(numpy.unique(segments_slic))
print (type(segments_slic))
#这一句是吧slic的结果保存下来，在cpp中调试用的
numpy.savetxt('test.txt', segments_slic, fmt='%1i')

segments_slic=segments_slic.astype(numpy.int32)
region_fh=fh.fh_seg(img,segments_slic,slicNum,sigma,c,min_size)
print("FH matrix")
print(type(region_fh))
print(region_fh)


fhNum=len(numpy.unique(region_fh))
print("FH number of segments: %d" % fhNum)
print("Slic number of segments: %d" % slicNum)


time1=datetime.now()
#img=gaussian_filter(img,0.1)
g=rag.construct_rag(lab,segments_slic,region_fh,slicNum,binNum)
#g=global_rag.construct_rag(img,segments_slic,region_fh,slicNum,binNum)
time2=datetime.now()
collapse=time2-time1
print('total processing time:')
print(collapse.total_seconds())
print ('here is node info')
print(g.edges())
print(g.nodes())
print('edge num')
print(len(g.edges()))
print('graph node num')
print(len(g.nodes()))
numpy.savetxt('fh_label.txt', region_fh, fmt='%1i')
numpy.savetxt('slic_label.txt', segments_slic, fmt='%1i')
relab, fw, inv = relabel_sequential(segments_slic)
numpy.savetxt('relabel_slic.txt', segments_slic, fmt='%1i')

file_g = open('g.obj', 'w')
file_g_final = open('g_final.obj', 'w')
file_fh=open('fh.obj','w')
file_num=open('num.obj','w')
pickle.dump(g, file_g)
pickle.dump(region_fh,file_fh)
pickle.dump(fhNum,file_num)
file_final=open('final.obj','w')
file_map = open('map.obj', 'w')

finalLabel,map_array=buildFinalLabel(g,region_fh,fhNum,n_segments)
map_array=numpy.array(map_array)
finalLabel=numpy.array(finalLabel)
pickle.dump(g, file_g_final)
pickle.dump(finalLabel,file_final)
pickle.dump(map_array,file_map)
finalNum=len(numpy.unique(finalLabel))
print('finalNum')
print(finalNum)



plt.imshow(img)
plt.figure()
plt.imshow(mark_boundaries(img, segments_slic,color=(1,0,0)))
plt.imsave("fishMan_slic.jpg",mark_boundaries(img, segments_slic,color=(1,0,0)))
plt.figure()
plt.imshow(mark_boundaries(img,region_fh,color=(1,0,0)))
plt.imsave("fishMan_Hybrid.jpg",mark_boundaries(img,region_fh,color=(1,0,0)))
plt.figure()
plt.imshow(mark_boundaries(img,finalLabel,color=(1,0,0)))
plt.imsave("fishMan_final.jpg",mark_boundaries(img,finalLabel,color=(1,0,0)))
plt.show()
numpy.savetxt('finalLabel.txt', finalLabel, fmt='%1i')

fh = felzenszwalb(img, scale=100, sigma=0.5, min_size=50)
#savePath='/Users/yuan/BaiduYun/MyDocument/workspace/MyMatlab/superpixel_benchmark/result/fh/fh_200/62096..mat'
#sio.savemat(savePath,{'finalLabel':fh})
