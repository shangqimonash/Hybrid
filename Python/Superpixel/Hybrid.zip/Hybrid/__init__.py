# -*- coding: utf-8 -*-
'''
from _construct_rag import construct_rag

__all__ = [construct_rag]
'''
from _global_rag import  construct_rag

__all__ = [construct_rag]