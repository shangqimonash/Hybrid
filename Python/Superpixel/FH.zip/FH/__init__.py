# -*- coding: utf-8 -*-
from _fh import fh_seg

__all__ = [fh_seg]